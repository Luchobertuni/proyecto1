<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <meta name="viewport" content="width= device-width, initial-scale=1">
    <link href="./css/style.css" rel="stylesheet" >
    <link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">
    <title>Rutas</title>
  </head>
  <body>
    <div class="contenedor">
    <div>
      <header>
        <h1><a href="trabajo.php"><img src="./imagenes/logo.jpg" height="200px" width="200px" class="logo"></a></h1>
      <div class="titulo">
      <h2> Instaviaje </h2>
      </div>
        <div class="menu-usuario">
        <nav>
          <ul class="menu2">
  <!-- Agregar mas adelante perfil/ cuando inicia sesion -->
            <li> <a href="logintrabajo.php"> Iniciar sesión </a> </li>
            <li> <a href="formulariotrabajo.php"> Registrarse </a> </li>
            <form action="">
            <li>  <img src="./imagenes/lupa.png" width="20px" height="20px"> <input type="search" name="Buscador" class="buscar" value="buscar">  </li>
            </form>

        </ul>
        </nav>
      </div>
        <div class="menu-principal">
        <nav >
          <ul class="menu">
            <li> <a href="trabajo.php"> Home </a> </li>
            <li> <a href=""> Contacto </a> </li>
            <li> <a href="faqs.php"> FaQs </a> </li>
        </ul>
        </nav>
      </div>

      </header>
      <br><br><br><br><br><br><br><br><br><br><br>
    <h2> Bienenido!</h2>
    <b>Te mostramos posibles rutas y caminos que podes recorrer!</b>
    <br>
    <br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <br>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

    </div>
    <footer>
    <div class="menu-footer">
      <nav>
      <ul>
        <li> <a href="trabajo.php">  Home </a> </li>
        <li> <a href="malito:instaviaje@gmail.com">  Contactanos! </a> </li>
        <li> <a href="#"> Redes </a> </li>
        <div>
        <li> <img src="./imagenes/face.png" width="50px" height="50px" class="face"> </li>
        <li> <img src="./imagenes/tw.png" width="50px" height="50px" class="tw"> </li>
      </div>
    </ul>
    </nav>
    </div>

    </footer>
    </div>
      </body>
    </html>
